package com.youkhainda.viewsync.ui.screen

import android.view.ViewGroup
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView
import com.youkhainda.viewsync.data.model.SyncSession
import com.youkhainda.viewsync.ui.viewmodel.SyncPlayerUiState
import com.youkhainda.viewsync.ui.viewmodel.SyncPlayerViewModel
import kotlinx.coroutines.delay

@Composable
fun SyncPlayerScreen(
    sessionId: String,
    viewModel: SyncPlayerViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsState()
    val syncState by viewModel.syncState.collectAsState()
    val videoOffsets by viewModel.videoOffsets.collectAsState()

    LaunchedEffect(sessionId) {
        viewModel.loadSyncSession(sessionId)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        when (val state = uiState) {
            is SyncPlayerUiState.Loading -> {
                CircularProgressIndicator(
                    modifier = Modifier.align(Alignment.Center),
                )
            }

            is SyncPlayerUiState.Success -> {
                SyncPlayerContent(
                    session = state.session,
                    shareLink = state.shareLink,
                    syncState = syncState,
                    videoOffsets = videoOffsets,
                    onPlay = { viewModel.play() },
                    onPause = { viewModel.pause() },
                    onSeek = { viewModel.seekToPosition(it) },
                    onRecordCue = { videoIdx, time, desc -> viewModel.recordSyncCue(videoIdx, time, desc) },
                    onGenerateLink = { viewModel.generateShareLink() },
                )
            }

            is SyncPlayerUiState.Error -> {
                ErrorScreen(message = state.message)
            }
        }
    }
}

@Composable
private fun SyncPlayerContent(
    session: SyncSession,
    shareLink: String,
    syncState: com.youkhainda.viewsync.data.model.SyncState,
    videoOffsets: Map<Int, Long>,
    onPlay: () -> Unit,
    onPause: () -> Unit,
    onSeek: (Long) -> Unit,
    onRecordCue: (Int, Long, String) -> Unit,
    onGenerateLink: () -> Unit,
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(MaterialTheme.colorScheme.background),
    ) {
        // Header
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            color = MaterialTheme.colorScheme.primary,
            shape = RoundedCornerShape(8.dp),
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Text(
                    text = session.name,
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.onPrimary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = "${session.videoIds.size} videos | ${session.syncCues.size} sync cues",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f),
                )
            }
        }

        // Video Grid
        LazyVideoGrid(
            videoIds = session.videoIds,
            syncState = syncState,
            videoOffsets = videoOffsets,
            onRecordCue = onRecordCue,
        )

        // Playback Controls
        PlaybackControlsSection(
            isPlaying = syncState.isPlaying,
            currentPosition = syncState.currentPlayPosition,
            onPlay = onPlay,
            onPause = onPause,
            onSeek = onSeek,
        )

        // Sync Cues List
        if (session.syncCues.isNotEmpty()) {
            SyncCuesSection(session.syncCues)
        }

        // Share Section
        ShareSection(
            shareLink = shareLink,
            onGenerateLink = onGenerateLink,
        )

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
private fun LazyVideoGrid(
    videoIds: List<String>,
    syncState: com.youkhainda.viewsync.data.model.SyncState,
    videoOffsets: Map<Int, Long>,
    onRecordCue: (Int, Long, String) -> Unit,
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        videoIds.forEachIndexed { index, videoId ->
            VideoPlayerCard(
                videoId = videoId,
                videoIndex = index,
                currentPosition = syncState.currentPlayPosition,
                offset = videoOffsets[index] ?: 0L,
                isPlaying = syncState.isPlaying,
                onRecordCue = { time, desc -> onRecordCue(index, time, desc) },
            )
        }
    }
}

@Composable
private fun VideoPlayerCard(
    videoId: String,
    videoIndex: Int,
    currentPosition: Long,
    offset: Long,
    isPlaying: Boolean,
    onRecordCue: (Long, String) -> Unit,
) {
    var currentTime by remember { mutableLongStateOf(0L) }
    var youtubePlayer by remember { mutableStateOf<YouTubePlayer?>(null) }
    var showCueDialog by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column {
            // YouTube Player
            AndroidView(
                factory = { context ->
                    YouTubePlayerView(context).apply {
                        layoutParams = ViewGroup.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            dpToPx(200),
                        )
                        addYouTubePlayerListener(object : AbstractYouTubePlayerListener() {
                            override fun onReady(player: YouTubePlayer) {
                                youtubePlayer = player
                                player.cueVideo(videoId, offset / 1000f)
                            }

                            override fun onCurrentSecond(youtubePlayer: YouTubePlayer, second: Float) {
                                currentTime = (second * 1000).toLong()
                            }

                            override fun onStateChange(
                                youtubePlayer: YouTubePlayer,
                                state: com.pierfrancescosoffritti.androidyoutubeplayer.core.enums.YouTubePlayerState,
                            ) {
                                // Handle state changes
                            }
                        })
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
            )

            // Video Controls
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "Video ${videoIndex + 1}",
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.weight(1f),
                )

                IconButton(
                    onClick = { showCueDialog = true },
                    modifier = Modifier.size(32.dp),
                ) {
                    Icon(
                        imageVector = Icons.Default.Bookmark,
                        contentDescription = "Record sync cue",
                        modifier = Modifier.size(20.dp),
                    )
                }
            }
        }
    }

    if (showCueDialog) {
        RecordCueDialog(
            onDismiss = { showCueDialog = false },
            onConfirm = { description ->
                onRecordCue(currentTime, description)
                showCueDialog = false
            },
        )
    }
}

@Composable
private fun PlaybackControlsSection(
    isPlaying: Boolean,
    currentPosition: Long,
    onPlay: () -> Unit,
    onPause: () -> Unit,
    onSeek: (Long) -> Unit,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(8.dp),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text = "Playback Controls",
                style = MaterialTheme.typography.labelLarge,
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { onSeek(maxOf(0, currentPosition - 5000)) }) {
                    Icon(Icons.Default.SkipPrevious, contentDescription = "Rewind")
                }

                FloatingActionButton(
                    onClick = if (isPlaying) onPause else onPlay,
                    modifier = Modifier.size(56.dp),
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                    )
                }

                IconButton(onClick = { onSeek(currentPosition + 5000) }) {
                    Icon(Icons.Default.SkipNext, contentDescription = "Fast forward")
                }
            }

            Text(
                text = formatTime(currentPosition),
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.align(Alignment.CenterHorizontally),
            )
        }
    }
}

@Composable
private fun SyncCuesSection(
    cues: List<com.youkhainda.viewsync.data.model.SyncCue>,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(8.dp),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Text(
                text = "Sync Cues (${cues.size})",
                style = MaterialTheme.typography.labelLarge,
            )

            cues.forEach { cue ->
                Text(
                    text = "Video ${cue.videoIndex + 1} @ ${formatTime(cue.cueTime)}" +
                        if (cue.description.isNotEmpty()) " - ${cue.description}" else "",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}

@Composable
private fun ShareSection(
    shareLink: String,
    onGenerateLink: () -> Unit,
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(8.dp),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Button(
                onClick = onGenerateLink,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Generate Share Link")
            }

            if (shareLink.isNotEmpty()) {
                SelectionContainer {
                    Text(
                        text = shareLink,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.background, RoundedCornerShape(4.dp))
                            .padding(8.dp),
                    )
                }
            }
        }
    }
}

@Composable
private fun RecordCueDialog(
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var description by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Sync Cue") },
        text = {
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Cue description (optional)") },
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            Button(onClick = { onConfirm(description) }) {
                Text("Confirm")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        },
    )
}

@Composable
private fun ErrorScreen(message: String) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Icon(
                imageVector = Icons.Default.Error,
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = MaterialTheme.colorScheme.error,
            )
            Text(
                text = "Error",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.error,
            )
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
            )
        }
    }
}

private fun formatTime(milliseconds: Long): String {
    val seconds = (milliseconds / 1000) % 60
    val minutes = (milliseconds / (1000 * 60)) % 60
    val hours = milliseconds / (1000 * 60 * 60)

    return when {
        hours > 0 -> String.format("%02d:%02d:%02d", hours, minutes, seconds)
        else -> String.format("%02d:%02d", minutes, seconds)
    }
}

private fun dpToPx(dp: Int): Int {
    return (dp * android.content.res.Resources.getSystem().displayMetrics.density).toInt()
}
