package com.youkhainda.viewsync.data.remote

import com.youkhainda.viewsync.data.model.*
import retrofit2.http.GET
import retrofit2.http.Query

interface YouTubeApiService {
    
    @GET("search")
    suspend fun searchVideos(
        @Query("part") part: String = "snippet",
        @Query("q") query: String,
        @Query("type") type: String = "video",
        @Query("maxResults") maxResults: Int = 25,
        @Query("key") apiKey: String,
    ): YouTubeSearchResponse

    @GET("videos")
    suspend fun getVideoDetails(
        @Query("part") part: String = "contentDetails",
        @Query("id") videoIds: String, // comma-separated
        @Query("key") apiKey: String,
    ): YouTubeVideoDetailsResponse
}

// Helper to parse ISO 8601 duration to milliseconds
fun parseDuration(isoDuration: String): Long {
    // Format: PT10M30S, PT1H20M30S, etc.
    val regex = """PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?""".toRegex()
    val match = regex.matchEntire(isoDuration) ?: return 0L
    
    val hours = match.groupValues[1].takeIf { it.isNotEmpty() }?.toLong() ?: 0L
    val minutes = match.groupValues[2].takeIf { it.isNotEmpty() }?.toLong() ?: 0L
    val seconds = match.groupValues[3].takeIf { it.isNotEmpty() }?.toLong() ?: 0L
    
    return (hours * 3600 + minutes * 60 + seconds) * 1000
}
